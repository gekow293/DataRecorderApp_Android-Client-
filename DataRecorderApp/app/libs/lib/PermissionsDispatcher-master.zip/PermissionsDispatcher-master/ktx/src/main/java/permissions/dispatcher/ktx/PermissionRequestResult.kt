package permissions.dispatcher.ktx

internal enum class PermissionResult {
    GRANTED,
    DENIED,
    DENIED_AND_DISABLED
}
