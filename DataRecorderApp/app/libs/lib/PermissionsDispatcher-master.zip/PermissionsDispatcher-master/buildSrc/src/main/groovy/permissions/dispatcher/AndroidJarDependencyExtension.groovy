package permissions.dispatcher

import javax.annotation.Nullable

class AndroidJarDependencyExtension {
    @Nullable
    String directory
}
