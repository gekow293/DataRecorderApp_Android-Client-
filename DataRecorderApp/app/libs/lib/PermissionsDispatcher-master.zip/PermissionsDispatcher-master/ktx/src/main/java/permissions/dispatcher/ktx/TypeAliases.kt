package permissions.dispatcher.ktx

import permissions.dispatcher.PermissionRequest

internal typealias Fun = () -> Unit
internal typealias ShowRationaleFun = (PermissionRequest) -> Unit
